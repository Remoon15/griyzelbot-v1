const menunya = (prefix) => {
	return`┌━━֍  〔 🪀*${NamaBot}* 🪀〕
│
│ █▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█
│ █░░╦─╦╔╗╦─╔╗╔╗╔╦╗╔╗░░█
│ █░░║║║╠─║─║─║║║║║╠─░░█
│ █░░╚╩╝╚╝╚╝╚╝╚╝╩─╩╚╝░░█
│ █▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█
│
├━━֍  〔 🪀 *OWNER* 🪀〕
├ᐷ .addrespon
├ᐷ .autorespon 1/0
├ᐷ .bc
├ᐷ .bcaudio
├ᐷ .clearall
├ᐷ .creategrup
├ᐷ .culik
├ᐷ .delcmd
├ᐷ .exif
├ᐷ .getscmd
├ᐷ .jadibot
├ᐷ .listcmd
├ᐷ .mute
├ᐷ .nsfw 1/0
├ᐷ .offline
├ᐷ .online
├ᐷ .public
├ᐷ .restart
├ᐷ .tobc
├ᐷ .self
├ᐷ .setbio
├ᐷ .setcmd
├ᐷ .setprefix
├ᐷ .setprofile
├ᐷ .shutdown
├ᐷ .stopjadibot
└━━֍  
┌━━֍  〔 🪀 *UPLOAD SW* 🪀〕
├ᐷ .spamsw
├ᐷ .upswteks
├ᐷ .upswlokasi
├ᐷ .upswsticker
├ᐷ .upswaudio
├ᐷ .upswvoice
├ᐷ .upswvideo
├ᐷ .upswgif
├ᐷ .upswimage
└━━֍  
┌━━֍  〔 🪀 *GRUP* 🪀〕
├ᐷ .ad ( reply pesan )
├ᐷ .add 628..dst
├ᐷ .antibug 1/0
├ᐷ .antidelete 1/0
├ᐷ .antilink 1/0
├ᐷ .caripesan
├ᐷ .fitnah
├ᐷ .getdeskgc
├ᐷ .grup
├ᐷ .getpp @tagtarget
├ᐷ .hacked
├ᐷ .hidetag
├ᐷ .infouser (reply pesan)
├ᐷ .kontak
├ᐷ .kick @tagmember
├ᐷ .kik  ( reply pesan )
├ᐷ .linkgrup
├ᐷ .listadmin
├ᐷ .listonline
├ᐷ .revoke
├ᐷ .setdeskgc
├ᐷ .setnamegc
├ᐷ .sider
├ᐷ .sticktag
├ᐷ .spam
├ᐷ .tag
├ᐷ .tagall
├ᐷ .tagme
├ᐷ .tospam
├ᐷ .totag
└━━֍  
┌━━֍  〔 🪀 *MAKER* 🪀〕
├ᐷ .attp
├ᐷ .battlefield
├ᐷ .blackbird
├ᐷ .codetxt
├ᐷ .coffeecup
├ᐷ .coffeecup2
├ᐷ .dance
├ᐷ .express
├ᐷ .foliokanan
├ᐷ .foliokiri
├ᐷ .glitch
├ᐷ .glow
├ᐷ .goldbutton
├ᐷ .golden
├ᐷ .googletxt
├ᐷ .hallowen
├ᐷ .hengker (reply Gambarnya)
├ᐷ .hengker2 (reply Gambarnya)
├ᐷ .maker2d2
├ᐷ .maker2d3
├ᐷ .maker2d4
├ᐷ .maker3d
├ᐷ .maker3d2
├ᐷ .maker3d3
├ᐷ .maker3d4
├ᐷ .matrix
├ᐷ .neon
├ᐷ .nulis
├ᐷ .nuliskiri
├ᐷ .nuliskanan
├ᐷ .nostonk (reply Gambarnya)
├ᐷ .patrick 
├ᐷ .pornhub (teks|teks)
├ᐷ .qrcode
├ᐷ .readmore
├ᐷ .rip (reply Gambarnya)
├ᐷ .semoji
├ᐷ .shareloc
├ᐷ .silverbutton
├ᐷ .stonk (reply Gambarnya)
├ᐷ .spiderman
├ᐷ .spongebob (reply Gambarnya)
├ᐷ .summer
├ᐷ .tahta
├ᐷ .text3d
├ᐷ .tinyurl
├ᐷ .toimg
├ᐷ .tomp3
├ᐷ .totext
├ᐷ .tourl
├ᐷ .transformer
├ᐷ .ttp
├ᐷ .tts
├ᐷ .vampire
├ᐷ .viewonce
├ᐷ .warrior
├ᐷ .wooden
┌━━֍   〔 🪀 *DOWNLOADER* 🪀〕
├ᐷ .dafontdl (link Dafont)
├ᐷ .igstory
├ᐷ .igdl
├ᐷ .mediafire
├ᐷ .play
├ᐷ .tiktok
├ᐷ .ytmp3
├ᐷ .ytmp4 
├ᐷ .ytdownload 
└━━֍  
┌━━֍  〔 🪀 *FUN* 🪀〕
├ᐷ .artimimpi
├ᐷ .bilangangka
├ᐷ .bisakah
├ᐷ .cekpintar
├ᐷ .cekganteng
├ᐷ .cekcantik
├ᐷ .cekmati
├ᐷ .dadu
├ᐷ .dare
├ᐷ .delttc
├ᐷ .fdeface (error)
├ᐷ .fitnahpc
├ᐷ .hbd
├ᐷ .herolist
├ᐷ .herodetail
├ᐷ .jadian
├ᐷ .kapankah
├ᐷ .slot
├ᐷ .suit
├ᐷ .tictactoe
├ᐷ .truth
└━━֍  
┌━━֍  〔 🪀 *STICKER* 🪀〕
├ᐷ .sticker
├ᐷ .swm
├ᐷ .takestick
├ᐷ .colong
└━━֍  
┌━━֍  〔 🪀 *SEARCH* 🪀〕
├ᐷ .brainly
├ᐷ .dafontsearch (nama Font)
├ᐷ .githubstalk
├ᐷ .gimage
├ᐷ .google
├ᐷ .infogempa
├ᐷ .lirik
├ᐷ .pinterest
├ᐷ .playstore
├ᐷ .resepmasakan
├ᐷ .wiki
├ᐷ .ytsearch
└━━֍  
┌━━֍  〔 🪀 *WAR* 🪀〕
├ᐷ .xbug
├ᐷ .bugbutton
├ᐷ .bugrow
├ᐷ .bugcombine
├ᐷ .tesbug
├ᐷ .bugpc
├ᐷ .bugtroli2
├ᐷ .bugtroli3
├ᐷ .virtex
├ᐷ .tovirvid
├ᐷ .tovirgam
├ᐷ .bugkatalog (perbaikan)
├ᐷ .bugloc
├ᐷ .buglokasi
├ᐷ .x
└━━֍  
┌━━֍  〔 🪀 *STORAGE* 🪀〕
├ᐷ .addimage
├ᐷ .addsticker
├ᐷ .addvn
├ᐷ .delimage
├ᐷ .delsticker
├ᐷ .delvn
├ᐷ .liststicker
├ᐷ .listvn
├ᐷ .listimage
└━━֍  
┌━━֍  〔 🪀 *ASUPAN* 🪀〕
├ᐷ .asupan
└━━֍  
┌━━֍  〔 🪀 *TOLLS* 🪀〕
├ᐷ .get
├ᐷ .kalkulator
└━━֍  
┌━━֍  〔 🪀 *TENTANG BOT* 🪀〕
⏐
├ᐷ .listblock
├ᐷ .baileys
├ᐷ .delete
├ᐷ .getcaption
├ᐷ .listgrup
├ᐷ .owner
├ᐷ .q
├ᐷ .report (Pesan Errornya)
├ᐷ .rules
├ᐷ .runtime
├ᐷ .sewa
├ᐷ .speed
├ᐷ .status
├ᐷ .tes
└━━֍  
┌━━֍  〔 🪀 *CONVERT* 🪀〕
⏐
├ᐷ .balik (reply audio)
├ᐷ .bass (reply audio)
├ᐷ .detikvn (reply audio)
├ᐷ .detikvideo (reply audio)
├ᐷ .gemuk (reply audio)
├ᐷ .robot (reply audio)
⏐
└━━֍  〔 🪀 *${NamaBot}* 🪀〕`
}
exports.menunya = menunya